define( function() {
	return ( /<([\w:-]+)/ );
} );
